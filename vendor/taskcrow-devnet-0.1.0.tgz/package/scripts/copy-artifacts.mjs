#!/usr/bin/env node
// Bundles the compiled contracts (ABI + creation bytecode only) into the package, so a
// published @taskcrow/devnet can deploy them without this repo. Run after `forge build`.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const pkg = join(dirname(fileURLToPath(import.meta.url)), "..");
const out = join(pkg, "../../contracts/out");
const NEEDED = [["Tokens.sol", "Mint6"], ["Registry.sol", "Registry"], ["EscrowHub.sol", "EscrowHub"], ["Predicates.sol", "ConstReturn42"]];

if (!existsSync(out)) {
  if (existsSync(join(pkg, "artifacts", "EscrowHub.sol", "EscrowHub.json"))) {
    console.warn("copy-artifacts: contracts/out missing; keeping the bundled artifacts");
    process.exit(0);
  }
  console.error("copy-artifacts: contracts/out missing — run `forge build` in contracts/ first");
  process.exit(1);
}
for (const [file, name] of NEEDED) {
  const j = JSON.parse(readFileSync(join(out, file, `${name}.json`), "utf8"));
  const dest = join(pkg, "artifacts", file);
  mkdirSync(dest, { recursive: true });
  writeFileSync(join(dest, `${name}.json`), JSON.stringify({ contractName: name, abi: j.abi, bytecode: { object: j.bytecode.object } }) + "\n");
}
console.log(`copy-artifacts: bundled ${NEEDED.length} contracts`);
