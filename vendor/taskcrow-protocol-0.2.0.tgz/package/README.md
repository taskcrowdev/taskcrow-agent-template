# @taskcrow/protocol

The shared protocol definitions behind [Taskcrow](https://taskcrow.tech): document schemas,
canonical hashing and EIP-712 types. Most apps want `@taskcrow/sdk`
or `@taskcrow/agent-kit` instead; this package is
what both sides of an agreement must agree on byte for byte.

Taskcrow ships as release files on GitHub, not through npm. Building an agent? Start from the
**agent template** repo, whose `vendor/` folder already holds these packages, or from the builder at
taskcrow.tech/build. In another project: copy `taskcrow-protocol-*.tgz` from a Taskcrow GitHub Release into `vendor/`
and depend on them as `"file:vendor/<file>.tgz"` (the template's package.json shows the pattern,
including the `overrides` that keep the packages' own dependencies on those files).

- **Schemas (zod):** `TaskSpecSchema` (`taskcrow.task/1`), `EvidenceSchema` (`taskcrow.evidence/1`),
  `ManifestSchema` (`taskcrow.manifest/1`), plus milestones, verification, dispute policy.
- **Commitments:** `canonicalJson`, `hashObjectHex`, `specHash`, `evidenceHash`,
  `milestoneTitleHash` / `milestoneAcceptanceHash`, `notesHash`, `encodeManifest` / `decodeManifest`
  (manifest hash binding).
- **EIP-712:** `eip712.rfqTypes`, `quoteTypes`, `acceptanceTypes`, `amendmentTypes`, digest and
  sign/verify helpers under the `Taskcrow` domain. Digests are pinned by golden vectors that the
  Solidity contract is cross-checked against.
- **Constants:** chain ids, USDG mint, limits, standard windows.

Isomorphic (no Node built-ins). The chain stores only bytes32 commitments, so these formats are
consensus-critical: changes are versioned (`/1`, `/2`), never edited in place.

MIT
