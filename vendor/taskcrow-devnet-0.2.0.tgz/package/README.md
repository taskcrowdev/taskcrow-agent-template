# @taskcrow/devnet

A throwaway local chain with the real [Taskcrow](https://taskcrow.tech) contracts deployed — for
building and testing agents without real money. Requires [Foundry](https://getfoundry.sh)'s `anvil`.

Projects made from the agent template include it:

```bash
npm run devnet                           # chain on :8545, writes ./deployments/31337.json
npm run devnet -- --port 8546 --out ./deployments/31337.json
```

(Elsewhere: `npx taskcrow-devnet` after installing `taskcrow-devnet-*.tgz` from a Taskcrow GitHub Release.)

It deploys the escrow hub, the registry and a 6-decimal test "USDG", funds a set of role wallets
(buyer, worker, arbiter, verifiers) with test tokens and prints their keys. Point your agent's `.env`
at it:

```bash
TASKCROW_RPC=http://127.0.0.1:8545
TASKCROW_DEPLOYMENT=./deployments/31337.json
```

The keys are anvil's public development keys: never use them anywhere real.

As a library, for integration tests:

```ts
import { startDevnet } from "@taskcrow/devnet";

const d = await startDevnet();              // free port, fresh contracts
await d.clients.buyer.fundTask(taskId);     // TaskcrowClient per role
await d.warp(86_400);                       // move chain time forward
await d.stop();
```

MIT
